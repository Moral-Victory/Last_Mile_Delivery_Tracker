// ==========================================
// 🤖 AI-SLOP CORE LOGIC AND ORCHESTRATION
// ==========================================

const API_BASE = window.location.origin;

let token = localStorage.getItem('ai_slop_token') || null;
let currentUser = null;

// Initialize app state
document.addEventListener('DOMContentLoaded', () => {
  console.log('[AI-JS] Initializing client synapses...');
  setupConsoleLoops();
  
  if (token) {
    // Attempt to decode role from local token
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      currentUser = payload;
      showDashboard();
    } catch (e) {
      logout();
    }
  }

  // Bind forms
  document.getElementById('login-form').addEventListener('submit', handleLogin);
  document.getElementById('register-form').addEventListener('submit', handleRegister);
  document.getElementById('create-order-form').addEventListener('submit', handleCreateOrder);
  document.getElementById('admin-create-zone-form').addEventListener('submit', handleCreateZone);
  document.getElementById('admin-rates-form').addEventListener('submit', handleUpdateRates);

  // Periodic polling for order list and simulated notifications outbox
  setInterval(() => {
    if (token) {
      refreshData();
    }
  }, 5000);
});

// Write to AI log terminal
function logToTerminal(message) {
  const term = document.getElementById('ai-logs-terminal');
  const timestamp = new Date().toLocaleTimeString();
  term.innerHTML += `<br>[${timestamp}] ${message}`;
  term.scrollTop = term.scrollHeight;
}

// Generate funny AI logs
function setupConsoleLoops() {
  const phrases = [
    "Predicting courier synapse coordinate vectors...",
    "Synergistic node coefficient optimization: 99.87%",
    "Refreshing global delivery ledger blocks...",
    "Querying deep neural model weights for traffic forecasting...",
    "Bypassing local execution policy parameters...",
    "Running Euclidean matrix heuristic overlays...",
    "Evaluating package dimensions volume metrics...",
    "Re-routing delayed drones to standby stations...",
    "Calibrating COD surcharges for maximum ROI..."
  ];

  setInterval(() => {
    const randomPhrase = phrases[Math.floor(Math.random() * phrases.length)];
    logToTerminal(`[AI-AGENT] ${randomPhrase}`);
  }, 8000);
}

// ==========================================
// AUTH FLOWS
// ==========================================

async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  logToTerminal(`Initiating authentication handshake for ${email}...`);

  try {
    const res = await fetch(`${API_BASE}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || data.error || 'Authentication aborted by AI');

    token = data.token;
    currentUser = data.user;
    localStorage.setItem('ai_slop_token', token);
    
    logToTerminal(`Handshake verified. Token payload decoded successfully.`);
    showDashboard();
  } catch (err) {
    logToTerminal(`❌ Auth Synapse Error: ${err.message}`);
    alert(err.message);
  }
}

async function handleRegister(e) {
  e.preventDefault();
  const name = document.getElementById('reg-name').value;
  const email = document.getElementById('reg-email').value;
  const password = document.getElementById('reg-password').value;

  logToTerminal(`Registering client identity: ${email}...`);

  try {
    const res = await fetch(`${API_BASE}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password, role: 'customer' })
    });
    
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || data.error || 'Registration failed');

    logToTerminal(`Client registry updated. Credentials finalized.`);
    alert(data.message);
    document.getElementById('login-email').value = email;
    document.getElementById('login-password').value = password;
  } catch (err) {
    logToTerminal(`❌ Registry Error: ${err.message}`);
    alert(err.message);
  }
}

function quickLogin(email, password) {
  document.getElementById('login-email').value = email;
  document.getElementById('login-password').value = password;
  document.getElementById('login-form').dispatchEvent(new Event('submit'));
}

function logout() {
  token = null;
  currentUser = null;
  localStorage.removeItem('ai_slop_token');
  document.getElementById('auth-panel').classList.remove('hidden');
  document.getElementById('main-dashboard').style.display = 'none';
  document.getElementById('order-details-panel').style.display = 'none';
  logToTerminal("Session terminated. Cache cleared.");
}

// ==========================================
// NAVIGATION & VIEW SWITCHING
// ==========================================

function showDashboard() {
  document.getElementById('auth-panel').classList.add('hidden');
  document.getElementById('main-dashboard').style.display = 'block';
  
  // Update profiles
  document.getElementById('session-user-name').innerText = currentUser.name || currentUser.email;
  document.getElementById('session-role-badge').innerText = currentUser.role.toUpperCase();

  // Hide all roles views
  document.getElementById('customer-dashboard').classList.remove('active');
  document.getElementById('admin-dashboard').classList.remove('active');
  document.getElementById('agent-dashboard').classList.remove('active');

  // Toggle visible dashboard
  if (currentUser.role === 'admin') {
    document.getElementById('admin-dashboard').classList.add('active');
    loadAdminConfig();
    loadAdminOrders();
  } else if (currentUser.role === 'customer') {
    document.getElementById('customer-dashboard').classList.add('active');
    triggerRateCalculation();
    loadCustomerOrders();
  } else if (currentUser.role === 'agent') {
    document.getElementById('agent-dashboard').classList.add('active');
    loadAgentOrders();
  }
  
  refreshData();
}

function refreshData() {
  if (currentUser.role === 'admin') {
    loadAdminOrders();
  } else if (currentUser.role === 'customer') {
    loadCustomerOrders();
  } else if (currentUser.role === 'agent') {
    loadAgentOrders();
  }
  loadNotificationsInbox();
}

function switchAdminTab(subpanelId) {
  document.querySelectorAll('.admin-subpanel').forEach(p => p.style.display = 'none');
  document.getElementById(subpanelId).style.display = 'block';
  document.querySelectorAll('.admin-dashboard .tab-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
}

// ==========================================
// RATE CALCULATION ENGINE PREVIEW
// ==========================================

let rateDebounceTimer;
function triggerRateCalculation() {
  clearTimeout(rateDebounceTimer);
  rateDebounceTimer = setTimeout(async () => {
    const pickupArea = document.getElementById('order-pickup-area').value;
    const dropArea = document.getElementById('order-drop-area').value;
    const length = document.getElementById('order-length').value;
    const width = document.getElementById('order-width').value;
    const height = document.getElementById('order-height').value;
    const actualWeight = document.getElementById('order-weight').value;
    const orderType = document.getElementById('order-type').value;
    const paymentType = document.getElementById('order-payment').value;

    try {
      const res = await fetch(`${API_BASE}/api/orders/calculate-rate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pickupArea, dropArea, length, width, height, actualWeight, orderType, paymentType })
      });

      if (!res.ok) throw new Error("Calculation rejected");
      const calc = await res.json();

      document.getElementById('rate-route').innerText = `${calc.pickupZone} ➡️ ${calc.dropZone} (${calc.isIntraZone ? 'Intra-Zone' : 'Inter-Zone'})`;
      document.getElementById('rate-vol-weight').innerText = `${calc.volumetricWeight} Kg`;
      document.getElementById('rate-charge-weight').innerText = `${calc.chargeableWeight} Kg`;
      document.getElementById('rate-per-kg').innerText = `$${calc.perKgRate}/Kg`;
      document.getElementById('rate-cod-fee').innerText = `$${calc.codSurcharge}`;
      document.getElementById('rate-grand-total').innerText = `$${calc.totalCharge}`;

    } catch (e) {
      document.getElementById('rate-route').innerText = "Routing synapse broken (Unmapped zone)";
      document.getElementById('rate-grand-total').innerText = "N/A";
    }
  }, 300);
}

// ==========================================
// CUSTOMER ACTIONS
// ==========================================

async function handleCreateOrder(e) {
  e.preventDefault();
  
  const payload = {
    pickupAddress: document.getElementById('order-pickup-addr').value,
    pickupArea: document.getElementById('order-pickup-area').value,
    dropAddress: document.getElementById('order-drop-addr').value,
    dropArea: document.getElementById('order-drop-area').value,
    length: parseFloat(document.getElementById('order-length').value),
    width: parseFloat(document.getElementById('order-width').value),
    height: parseFloat(document.getElementById('order-height').value),
    actualWeight: parseFloat(document.getElementById('order-weight').value),
    orderType: document.getElementById('order-type').value,
    paymentType: document.getElementById('order-payment').value
  };

  logToTerminal(`Initializing shipping payload routing handshake...`);

  try {
    const res = await fetch(`${API_BASE}/api/orders`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });
    
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Failed to request courier allocation');

    logToTerminal(`Order ${data.order.id} recorded. Initial status: ${data.order.status}`);
    alert(`Payload dispatched! System auto-assignment logic resolved status to: ${data.order.status}`);
    
    // Clear Form
    document.getElementById('order-pickup-addr').value = '';
    document.getElementById('order-drop-addr').value = '';
    
    refreshData();
  } catch (err) {
    logToTerminal(`❌ Pipeline Error: ${err.message}`);
    alert(err.message);
  }
}

async function loadCustomerOrders() {
  try {
    const res = await fetch(`${API_BASE}/api/orders`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const orders = await res.json();
    
    const tbody = document.querySelector('#customer-orders-table tbody');
    tbody.innerHTML = '';
    
    orders.forEach(order => {
      tbody.innerHTML += `
        <tr>
          <td><a href="#" onclick="viewOrderDetails('${order.id}')" style="color: var(--accent-neon-green); font-family: monospace;">${order.id}</a></td>
          <td>${order.dropAddress} (${order.rateDetails.dropZone})</td>
          <td>$${order.rateDetails.totalCharge}</td>
          <td><span class="status-badge status-${order.status.toLowerCase().replace(' ', '_')}">${order.status}</span></td>
          <td>${order.agentName || '<span style="color: var(--text-muted);">Awaiting Dispatch</span>'}</td>
          <td>
            <button class="btn-quick" onclick="viewOrderDetails('${order.id}')">Diagnostics</button>
            ${order.status === 'Failed' ? `<button class="btn-quick" style="border-color: var(--accent-neon-pink); color: var(--accent-neon-pink);" onclick="viewOrderDetails('${order.id}')">Reschedule</button>` : ''}
          </td>
        </tr>
      `;
    });
  } catch (e) {
    console.error(e);
  }
}

// ==========================================
// ADMIN ACTIONS
// ==========================================

async function loadAdminOrders() {
  try {
    const res = await fetch(`${API_BASE}/api/orders`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const allOrders = await res.json();
    
    // Filter client side
    const statusFilter = document.getElementById('admin-filter-status').value;
    const zoneFilter = document.getElementById('admin-filter-zone').value;

    const filtered = allOrders.filter(o => {
      if (statusFilter && o.status !== statusFilter) return false;
      if (zoneFilter && o.rateDetails.pickupZone !== zoneFilter) return false;
      return true;
    });

    // Get config to fetch active agents list for the dropdown
    const configRes = await fetch(`${API_BASE}/api/config`);
    const systemConfig = await configRes.json();
    
    const tbody = document.querySelector('#admin-orders-table tbody');
    tbody.innerHTML = '';

    filtered.forEach(order => {
      // Build agent dropdown choices
      let agentOptions = `<option value="">-- Unassigned --</option>`;
      systemConfig.agents.forEach(agent => {
        agentOptions += `<option value="${agent.id}" ${order.agentId === agent.id ? 'selected' : ''}>${agent.name} (${agent.zone || 'No Zone'}) ${agent.available ? '🟢' : '🔴'}</option>`;
      });

      tbody.innerHTML += `
        <tr>
          <td><a href="#" onclick="viewOrderDetails('${order.id}')" style="color: var(--accent-neon-green); font-family: monospace;">${order.id}</a></td>
          <td>${order.customerEmail}</td>
          <td>${order.rateDetails.pickupZone} ➡️ ${order.rateDetails.dropZone}</td>
          <td>$${order.rateDetails.totalCharge}</td>
          <td>
            <select onchange="updateOrderStatus('${order.id}', this.value)" style="padding: 2px 5px; font-size: 0.8rem;">
              <option value="Pending" ${order.status === 'Pending' ? 'selected' : ''}>Pending</option>
              <option value="Assigned" ${order.status === 'Assigned' ? 'selected' : ''}>Assigned</option>
              <option value="Picked Up" ${order.status === 'Picked Up' ? 'selected' : ''}>Picked Up</option>
              <option value="In Transit" ${order.status === 'In Transit' ? 'selected' : ''}>In Transit</option>
              <option value="Out for Delivery" ${order.status === 'Out for Delivery' ? 'selected' : ''}>Out for Delivery</option>
              <option value="Delivered" ${order.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
              <option value="Failed" ${order.status === 'Failed' ? 'selected' : ''}>Failed</option>
            </select>
          </td>
          <td>
            <select onchange="overrideOrderAgent('${order.id}', this.value)" style="padding: 2px 5px; font-size: 0.8rem;">
              ${agentOptions}
            </select>
          </td>
          <td>
            <button class="btn-quick" onclick="triggerAdminAutoAssign('${order.id}')">Auto-Assign</button>
            <button class="btn-quick" onclick="viewOrderDetails('${order.id}')">Timeline</button>
          </td>
        </tr>
      `;
    });

  } catch (e) {
    console.error(e);
  }
}

async function loadAdminConfig() {
  try {
    const res = await fetch(`${API_BASE}/api/config`);
    const config = await res.json();
    
    // Fill Zones table
    const zoneBody = document.querySelector('#admin-zones-table tbody');
    zoneBody.innerHTML = '';
    config.zones.forEach(z => {
      zoneBody.innerHTML += `
        <tr>
          <td><strong>${z.name}</strong></td>
          <td style="font-family: monospace;">${z.areas.join(', ')}</td>
        </tr>
      `;
    });

    // Populate rates form fields
    document.getElementById('rate-b2c-intra').value = config.rateCards.b2c.intraZoneRate;
    document.getElementById('rate-b2c-inter').value = config.rateCards.b2c.interZoneRate;
    document.getElementById('rate-b2b-intra').value = config.rateCards.b2b.intraZoneRate;
    document.getElementById('rate-b2b-inter').value = config.rateCards.b2b.interZoneRate;
    document.getElementById('rate-b2c-cod').value = config.rateCards.codSurcharge.B2C;
    document.getElementById('rate-b2b-cod').value = config.rateCards.codSurcharge.B2B;

  } catch (e) {
    console.error(e);
  }
}

async function handleCreateZone(e) {
  e.preventDefault();
  const name = document.getElementById('admin-zone-name').value;
  const areas = document.getElementById('admin-zone-areas').value;

  try {
    const res = await fetch(`${API_BASE}/api/admin/zones`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ name, areas })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Failed to save zone');

    alert("Zone configured successfully.");
    document.getElementById('admin-create-zone-form').reset();
    loadAdminConfig();
  } catch (err) {
    alert(err.message);
  }
}

async function handleUpdateRates(e) {
  e.preventDefault();
  const payload = {
    b2c: {
      intraZoneRate: parseFloat(document.getElementById('rate-b2c-intra').value),
      interZoneRate: parseFloat(document.getElementById('rate-b2c-inter').value)
    },
    b2b: {
      intraZoneRate: parseFloat(document.getElementById('rate-b2b-intra').value),
      interZoneRate: parseFloat(document.getElementById('rate-b2b-inter').value)
    },
    codSurcharge: {
      B2C: parseFloat(document.getElementById('rate-b2c-cod').value),
      B2B: parseFloat(document.getElementById('rate-b2b-cod').value)
    }
  };

  try {
    const res = await fetch(`${API_BASE}/api/admin/rate-cards`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Failed to sync rates');

    alert("Tariff rate matrices updated.");
    loadAdminConfig();
  } catch (err) {
    alert(err.message);
  }
}

function openBehalfForm() {
  const email = document.getElementById('admin-behalf-email').value;
  if (!email) {
    alert("Please enter a customer email address first.");
    return;
  }
  
  // Shift temporarily to customer dashboard UI so admin can use the calculator form,
  // but keep role as admin. Customize form target logic!
  alert(`Configure order properties below. Order will be recorded under customer identity: ${email}`);
  
  // Inject Customer Dashboard View inside Admin space temporarily
  document.getElementById('customer-dashboard').classList.add('active');
  
  // Modify Create Order submission listener to override customer identity
  const form = document.getElementById('create-order-form');
  // Re-bind form with admin behalf trigger
  form.onsubmit = async (e) => {
    e.preventDefault();
    const payload = {
      pickupAddress: document.getElementById('order-pickup-addr').value,
      pickupArea: document.getElementById('order-pickup-area').value,
      dropAddress: document.getElementById('order-drop-addr').value,
      dropArea: document.getElementById('order-drop-area').value,
      length: parseFloat(document.getElementById('order-length').value),
      width: parseFloat(document.getElementById('order-width').value),
      height: parseFloat(document.getElementById('order-height').value),
      actualWeight: parseFloat(document.getElementById('order-weight').value),
      orderType: document.getElementById('order-type').value,
      paymentType: document.getElementById('order-payment').value,
      customerEmailOverride: email
    };

    try {
      const res = await fetch(`${API_BASE}/api/orders`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Failed behalf order');

      alert(`Behalf order recorded: ${data.order.id}`);
      form.onsubmit = null; // Unbind override
      showDashboard(); // Restore Dashboard views
    } catch (err) {
      alert(err.message);
    }
  };
}

async function overrideOrderAgent(orderId, agentId) {
  logToTerminal(`Admin overriding dispatcher routing values for ${orderId}...`);
  try {
    const res = await fetch(`${API_BASE}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ agentIdOverride: agentId || "" })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Agent override rejected');

    logToTerminal(`Routing ledger finalized for ${orderId}.`);
    refreshData();
  } catch (err) {
    alert(err.message);
  }
}

async function triggerAdminAutoAssign(orderId) {
  logToTerminal(`Triggering heuristic neural routing matrix matches for ${orderId}...`);
  try {
    const res = await fetch(`${API_BASE}/api/orders/${orderId}/auto-assign`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'No matches resolved');

    alert(`Auto-assigned! Matched Agent: ${data.order.agentName}`);
    refreshData();
  } catch (err) {
    alert(err.message);
  }
}

// ==========================================
// AGENT ACTIONS
// ==========================================

async function loadAgentOrders() {
  try {
    const res = await fetch(`${API_BASE}/api/orders`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const tasks = await res.json();
    
    const tbody = document.querySelector('#agent-orders-table tbody');
    tbody.innerHTML = '';

    tasks.forEach(task => {
      tbody.innerHTML += `
        <tr>
          <td><a href="#" onclick="viewOrderDetails('${task.id}')" style="color: var(--accent-neon-green); font-family: monospace;">${task.id}</a></td>
          <td>${task.pickupAddress} (${task.rateDetails.pickupZone})</td>
          <td>${task.dropAddress} (${task.rateDetails.dropZone})</td>
          <td>$${task.rateDetails.totalCharge}</td>
          <td>
            <select onchange="updateOrderStatus('${task.id}', this.value)" style="padding: 2px 5px; font-size: 0.8rem;">
              <option value="Assigned" ${task.status === 'Assigned' ? 'selected' : ''}>Assigned</option>
              <option value="Picked Up" ${task.status === 'Picked Up' ? 'selected' : ''}>Picked Up</option>
              <option value="In Transit" ${task.status === 'In Transit' ? 'selected' : ''}>In Transit</option>
              <option value="Out for Delivery" ${task.status === 'Out for Delivery' ? 'selected' : ''}>Out for Delivery</option>
              <option value="Delivered" ${task.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
              <option value="Failed" ${task.status === 'Failed' ? 'selected' : ''}>Failed</option>
            </select>
          </td>
          <td>
            <button class="btn-quick" onclick="viewOrderDetails('${task.id}')">View Specs</button>
          </td>
        </tr>
      `;
    });
  } catch (e) {
    console.error(e);
  }
}

// Global order status changer
async function updateOrderStatus(orderId, newStatus) {
  const comment = prompt("Enter status logs override description (Optional):", `Status updated to ${newStatus}`);
  logToTerminal(`Updating status of ${orderId} to ${newStatus}...`);

  try {
    const res = await fetch(`${API_BASE}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ status: newStatus, comment })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Status transition denied');

    logToTerminal(`Status for ${orderId} set to ${newStatus}.`);
    refreshData();
  } catch (err) {
    alert(err.message);
  }
}

// ==========================================
// ORDER DETAILS & RESCHEDULE
// ==========================================

let activeDetailsOrderId = null;

async function viewOrderDetails(orderId) {
  activeDetailsOrderId = orderId;
  document.getElementById('order-details-panel').style.display = 'block';
  document.getElementById('detail-order-id').innerText = orderId;

  logToTerminal(`Syncing diagnostic telemetry for ${orderId}...`);

  try {
    const res = await fetch(`${API_BASE}/api/orders/${orderId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const order = await res.json();

    document.getElementById('detail-pickup').innerText = `${order.pickupAddress} (${order.pickupArea} - Zone: ${order.rateDetails.pickupZone})`;
    document.getElementById('detail-drop').innerText = `${order.dropAddress} (${order.dropArea} - Zone: ${order.rateDetails.dropZone})`;
    document.getElementById('detail-dimensions').innerText = `${order.dimensions.length} x ${order.dimensions.width} x ${order.dimensions.height} cm`;
    document.getElementById('detail-weight').innerText = `${order.actualWeight} Kg`;
    document.getElementById('detail-vol-weight').innerText = `${order.rateDetails.volumetricWeight} Kg`;
    document.getElementById('detail-type').innerText = `${order.orderType} Type Rate`;
    document.getElementById('detail-payment').innerText = `${order.paymentType}`;
    document.getElementById('detail-charge').innerText = `$${order.rateDetails.totalCharge}`;
    document.getElementById('detail-agent').innerText = order.agentName || 'Unassigned';
    document.getElementById('detail-reschedule').innerText = order.rescheduleDate ? `Rescheduled to ${order.rescheduleDate}` : 'No reschedules logged';

    // Toggle Customer reschedule box
    const rescheduleZone = document.getElementById('customer-reschedule-zone');
    if (currentUser.role === 'customer' && order.status === 'Failed') {
      rescheduleZone.style.display = 'block';
    } else {
      rescheduleZone.style.display = 'none';
    }

    // Build timeline
    const timeline = document.getElementById('detail-timeline');
    timeline.innerHTML = '';
    order.trackingHistory.forEach(h => {
      const dt = new Date(h.timestamp).toLocaleString();
      timeline.innerHTML += `
        <div class="timeline-item">
          <div class="timeline-time">${dt}</div>
          <div><span class="status-badge status-${h.status.toLowerCase().replace(' ', '_')}">${h.status}</span></div>
          <div class="timeline-actor">Logged by: ${h.actor}</div>
          <div style="font-size: 0.85rem; margin-top: 3px;">"${h.comment}"</div>
        </div>
      `;
    });

  } catch (err) {
    alert(err.message);
  }
}

function closeDetails() {
  document.getElementById('order-details-panel').style.display = 'none';
  activeDetailsOrderId = null;
}

async function submitReschedule() {
  const dateVal = document.getElementById('reschedule-date-input').value;
  if (!dateVal) {
    alert("Please specify a valid scheduling calendar date.");
    return;
  }

  logToTerminal(`Sending reschedule request packet for ${activeDetailsOrderId}...`);

  try {
    const res = await fetch(`${API_BASE}/api/orders/${activeDetailsOrderId}/reschedule`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ rescheduleDate: dateVal })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Re-routing denied');

    alert(`Reschedule successful! New Status: ${data.order.status}. Reassigned to: ${data.order.agentName || 'Pending'}`);
    closeDetails();
    refreshData();
  } catch (err) {
    alert(err.message);
  }
}

// ==========================================
// NOTIFICATIONS/OUTBOX RENDERER
// ==========================================

async function loadNotificationsInbox() {
  try {
    const res = await fetch(`${API_BASE}/api/orders`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const orders = await res.json();
    
    // Collect all notifications across all active loaded orders
    let allNotifs = [];
    orders.forEach(o => {
      if (o.notifications) {
        o.notifications.forEach(n => {
          allNotifs.push({
            id: n.id,
            orderId: o.id,
            email: o.customerEmail,
            message: n.message,
            timestamp: n.timestamp
          });
        });
      }
    });

    // Sort by timestamp desc
    allNotifs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    const container = document.getElementById('notifications-inbox');
    if (allNotifs.length === 0) {
      container.innerHTML = `<div style="color: var(--text-muted); font-size: 0.8rem; text-align: center; padding: 20px;">No notifications dispatched in this session logs.</div>`;
      return;
    }

    container.innerHTML = '';
    allNotifs.slice(0, 15).forEach(n => {
      const timeStr = new Date(n.timestamp).toLocaleTimeString();
      container.innerHTML += `
        <div class="inbox-item">
          <div class="inbox-meta">
            <span>To: ${n.email}</span>
            <span>${timeStr}</span>
          </div>
          <div><strong>Order ${n.orderId} Alert:</strong> ${n.message}</div>
          <div style="font-size: 0.65rem; color: var(--accent-neon-green); margin-top: 3px; font-family: monospace;">[SMTP SUCCESS-CODE 250]</div>
        </div>
      `;
    });

  } catch (e) {
    console.error(e);
  }
}
