# 🌐 SYSTEM DESIGN WRITE-UP: AI-SYNERGIZED LAST-MILE DISPATCH
**Author:** DeepMind AI Simulator (Prompt Architecture Pipeline)
**Target Word Count:** ~500-600 words (Under 800 words limit)

---

## 1. Rate Calculation Engine Architecture
Our system deploys an AI-optimized pricing engine designed to eliminate hardcoding by querying an administrative rate ledger.
```mermaid
graph TD
    A[Order Input Parameters] --> B[Zone Detection Engine]
    B --> C{Intra or Inter Zone?}
    C -->|Intra| D[Intra-Zone Rate per Kg]
    C -->|Inter| E[Inter-Zone Rate per Kg]
    A --> F[Volumetric Weight Calculation]
    F --> G[Chargeable Weight Selector]
    A --> H[Actual Weight]
    H --> G
    D & E & G --> I[Base Cost Computation]
    A --> J[Payment Paradigm COD?]
    J -->|Yes| K[Apply COD Surcharge]
    J -->|No| L[Zero Surcharge]
    I & K & L --> M[Final Tariff Matrix Output]
```

### Heuristics & Formulations:
- **Volumetric Weight Calculation**: To prevent shipping high-volume, low-density cargo at a loss, we apply the standard volumetric formulation:
  $$\text{VolWeight} = \frac{\text{L} \times \text{W} \times \text{H}}{5000}$$
- **Chargeable Weight Selection**: The system dynamically runs a comparison logic:
  $$\text{ChargeableWeight} = \max(\text{ActualWeight}, \text{VolWeight})$$
- **Base Rate Application**: Looks up either the `b2b` or `b2c` rate card matching the client role, checks if the route is intra-zone or inter-zone, and calculates:
  $$\text{BaseCharge} = \text{ChargeableWeight} \times \text{PerKgRate}$$
- **COD Surcharge Integration**: Applies a fixed flat fee to Cash on Delivery shipments to cover cash collection risk profiles.

---

## 2. Zone Detection Approach
Our zone detection approach maps area codes (e.g. zip codes) to coordinate centroids in a non-relational database document.
- When an order is initialized, the pickup and dropoff zip codes are passed through a search vector.
- The system checks area membership in the zone collection.
- A zone center coordinate object (comprising latitude and longitude centroids) is registered for both source and destination. This center point serves as the basis for agent proximity calculations.

---

## 3. Auto-Assignment Logic & Distance Matrix
The auto-assignment mechanism resolves couriers using an Euclidean coordinate projection model.
1. **Available Agent Query**: Filters all users registered with the `agent` role who have the property `available: true`.
2. **Zone Alignment Bonus**: To minimize intra-city travel times, agents located in the same pickup zone receive a priority routing offset (represented as a negative distance bonus of `-100.0` units in the scoring matrix).
3. **Euclidean Distance Formula**: The spatial distance between the agent's current coordinates $(x_{agent}, y_{agent})$ and the pickup zone centroid coordinates $(x_{pickup}, y_{pickup})$ is calculated:
   $$\text{Distance} = \sqrt{(x_{agent} - x_{pickup})^2 + (y_{agent} - y_{pickup})^2}$$
4. **Optimal Dispatch Decision**: The agent with the lowest combined routing score $(\text{Distance} + \text{Zone Bonus})$ is assigned. If no available agents exist, the order is placed into a manual queue.

---

## 4. Failed Delivery Handling & Rescheduling Lifecycle
Our system implements an immutable status tracking ledger to preserve audit logs of all cargo state transitions.

```mermaid
sequenceDiagram
    participant Customer
    participant System Router
    participant Agent
    
    Agent->>System Router: Flag order status as "Failed"
    System Router->>System Router: Lock historical entry in ledger
    System Router->>Customer: Route mock SMTP tracking notification
    Customer->>System Router: Trigger Reschedule (Date input)
    System Router->>System Router: Mark status as "Assigned" / "Pending"
    System Router->>System Router: Re-run nearest agent lookup
    System Router->>Agent: Route assignment to new agent
```

- **Failure Flagging**: When an agent reports a delivery failure, the order is updated with a `Failed` status and the transition is logged.
- **Client Notification**: The notification engine routes an automated email alert to the customer's inbox.
- **Reschedule Resolution**: The customer selects a new delivery target date. On submission, the previous agent is released, and the auto-assignment engine executes to dispatch the shipment to the nearest agent available on the new schedule date.
